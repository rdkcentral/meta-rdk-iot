#pragma once

#define MATTER_PLUGINS_INIT \
    (void)0; /* No server side clusters */

